class Main {
  public static void main(String[] args) {
    String teks = "Saya berkata, \"Rajin belajar, ya!\"";
        System.out.println( teks );

  }
}