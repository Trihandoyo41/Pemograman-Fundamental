class Main {
  public static void main(String[] args) {
     String hasil = Main.salam();
     System.out.println(hasil);
  }
  
  public static String salam() {
    String hasil = "Salam Programmer!";
    return hasil;
   }
}
